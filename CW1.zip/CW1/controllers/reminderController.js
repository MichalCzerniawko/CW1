const reminder = require('../models/reminderModel'); 
const db = new reminder(); 
db.init();
/*
controller.get('/filter/:goal', function(request, response){
    console.log("filtering " , request.params.exciseGoals);
    let goal = request.params.goal;
    db.getEntriesByGoal(goal)
    .then((entries) => {
        response.render("entries", {
            "title": "Reminder List",
            "entries": entries
        });
    })
    .catch((err) => {
        console.log('Error: ')
        console.log(JSON.stringify(err))
    });
})
*/
exports.update_goals = function(req, res){
        db.getUpdateGoal(req.body.exciseGoals);
        res.redirect('/');
    
}
exports.remove_goals = function(req, res){ 
    console.log('Running remove goals')
    db.getRemoveGoal();
    res.redirect('/');
}
exports.entries_list = function(req, res) {
    res.send('<h1>Not yet implemented: show a list of guest book entries.</h1>');
    db.getAllEntries();   
}
exports.show_new_entries = function(req, res) {
    res.render('newEntry', {
    'title': 'Reminder list'
    })
   } 
   exports.post_new_entry = function(req, res) {

    if (!req.body.week) {
    response.status(400).send("Entries must have date.");
    return;
    }
    db.addEntry(req.body.week, req.body.achievement, req.body.exciseGoals);
    res.redirect('/');
   }
   exports.show_goal_entries = function(req, res) {
    console.log('filtering goal name', req.params.exciseGoals);
    let exerciseGoal = req.params.exciseGoals;
    db.getWeeklyEntries(exciseGoals).then((entries) => {
    res.render('entries', {
    'title': 'Reminder List',
    'entries': entries
    });
    }).catch((err) => {
    console.log('error handling goals', err);
    });
   }  
   exports.landing_page = function(req, res) {
    db.getAllEntries().then((list) => {
        res.render('entries', {
        'title': 'Reminder List',
        'entries': list
        });
        console.log('promise resolved');
        }).catch((err) => {
        console.log('promise rejected', err);
        })
   }
   exports.weekly_entries = function(req, res) {
    res.send('<h1>Displaying weekly entries</h1>');
    db.getWeeklyEntries();
   }
