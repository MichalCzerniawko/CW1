const express = require('express');
const router = require('./routes/reminderRoutes');
const app = express();
app.use('/', router); 
const nedb = require('nedb')
const mustache = require('mustache-express');
app.engine('mustache', mustache());
app.set('view engine', 'mustache');
const db = new nedb({filename:'training.db', autoload: true});
const path = require('path');
const public = path.join(__dirname, 'public');
app.use(express.static(public));
console.log('database created');
const bodyParser = require('body-parser')
app.use(express.urlencoded({extended:false}));
app.listen(3000, () => {
 console.log('Server started on port 3000. Ctrl^c to quit.');
}) 
            
            
        

 

