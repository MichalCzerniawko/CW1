const reminder = require('../models/reminderModel'); 
const userDao = require('../models/userModel.js'); 
const db = new reminder(); 
const express = require('express');
const path = require('path');
const app = express();
const db = new reminder();
//db.init();
exports.landing_page = function(req, res) {
    res.render('homepage', {
        'title': 'Homepage'
    });

}

exports.reminder_list = function(req, res) {
    db.getAllEntries().then((allEntries) => {
        res.render('trainingGoals', {
            'title': 'Reminder List',
            'reminder': allEntries,
            "user": req.user
        });
        console.log('promise resolved');
    }).catch((err) => {
        console.log('promise rejected', err);
    })
}

exports.show_new_reminder_goal = function(req, res) {
    res.render('insertForm', {
        'title': 'Insert data',
        'user': req.user.user
    });
}

exports.post_reminder_goal = function(req, res) {

    if(!req.body.name) {
        response.status(404).send("Goals must have user");
        return;
    }

    db.addNewEntry(req.body.name,req.body.week ,req.body.goal, req.body.duration,req.body.completed);
    res.redirect('/trainingReminders');
}

exports.delete_entry = function(req, res){
    db.deleteEntry(req.params.id);    
    res.redirect('/trainingReminders');
}
 
exports.show_update_entry = function(req, res) {
    res.render("update", {
        'title': 'Update Entry',
        'user': req.user.user
    });
}

exports.post_update_entry = function(req, res) {
    console.log('id in update_entry', req.params.id);
    db.updateEntry(req.params.id, req.body.name,req.body.week, req.body.goal, req.body.duration, req.body.completed);
    res.redirect('/trainingReminders');
}
exports.find_completed_entries = function(req, res) {
    db.getCompletedGoals().then((compLeated) => {
        res.render('completedGoals', {
            'title': 'Completed Goals',
            'completedGoals': compLeated,
            "user": req.user
        });
        console.log('promise resolved');
    }).catch((err) => {
        console.log('promise rejected', err);
    })
}
exports.find_incomplete_entries = function(req, res) {
    db.getIncompleteGoals().then((incompLoated) => {
        res.render('incompleteGoals', {
            'title': 'incomplete Goals',
            'incompleteGoals': incompLoated,
            "user": req.user
        });
        console.log('promise resolved');
    }).catch((err) => {
        console.log('promise rejected', err);
    })
}

exports.show_weekly_entries = function(req, res) {
    console.log('filtering week', req.params.week);

    let week = req.params.week;
    db.getPostsByWeek(week).then((Goals) => {
        res.render('GoalByWeek', {
            'title': 'Goals By Week',
            'GoalsByWeek': Goals
        });
    }).catch((err) => {
        console.log('error handling', err);
    })
}

exports.testError500 = function(req, res) {
    if(render) {
    res.render('error', {
        'title': 'Test Error 500'
    });
    } else {
    throw(error500);
    }
}

exports.show_login_page = function(req, res) {
    res.render('login', {
        'title': 'Goals: Login'
    });
}

exports.post_login = function(req, res) {
    console.log('serializeUser wrote', req.session.passport.user);
    res.redirect('/trainingGoals');
}

exports.show_register_page = function(req, res) {
    res.render("register");
}

exports.post_new_user = function(req, res) {
    const user = req.body.username;
    const password = req.body.pass;
    if(!user || !password ) {
        res.send(401, 'no user or no password');
        return;
    }
    userDAO.lookup(user, function(err, u) {
        if(u) {
            res.send(401, "User exists: ", user);
            return;
        }
        userDAO.create(user, password);
        res.redirect('login');
    })
}

exports.logout = function (req, res) {
    req.logout();
    res.redirect("login");
}


