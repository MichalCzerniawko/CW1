const nedb = require('nedb'); 
class reminder {
    constructor(dbFilePath) {
        if (dbFilePath) {
        this.db = new nedb({ filename: dbFilePath, autoload: true });
        console.log('DB connected to ' + dbFilePath);
        } else {
        this.db = new nedb();
        }
} 
        
        init() {
            this.db.insert({
            week: 15,
            achievement: '15km travel',
            duration: "5mins",
            completed: 'true',
            Goals: [{
               goalID: 1,
                goalDescription: 'Successfully'
            },
            {
                goalID: 2,
                goalDescription:'Failed'  
            },
            {
                goalID: 2,
                goalDescription:'in way'
            }
 ]
            },{
            week: 16,
            achievement: "Swimming",
            duration: "7mins",
            completed: 'false',
            Goals: [{
               goalID: 1,
                goalDescription: 'Successfully'
            },
            {
                goalID: 2,
                goalDescription:'Failed'  
            },
            {
                goalID: 2,
                goalDescription:'in way'
            }
 ]
            });
                    console.log(' entry inserted');         
}

getAllEntries() {
    return new Promise((resolve, reject) => {
        this.db.find({}, function(err, allEntries) {
            if(err) {
                reject(err);
            } else {
                resolve(allGoals);
                console.log('getAllEntries returns: ', allEntries);
            }
        })
    })
}

getCompleted() {
    return new Promise((resolve, reject) => {
        this.db.find({ completed: 'true'}, function(err, compLeted) {
            if(err) {
                reject(err);
            } else {
                resolve(compGoals);
                console.log('getCompleted returns: ', compLeted);
            }
        })
    })
}

getIncompleted() {
    return new Promise((resolve, reject) => {
        this.db.find({ completed: 'false'}, function(err, incomLeted) {
            if(err) {
                reject(err);
            } else {
                resolve(incompGoals);
                console.log('getIncompleted returns: ', incomLeted);
            }
        })
    })
}

/*
    getWeeklyEntries() {
        return new Promise((resolve, reject) => {
        this.db.find({ week:'' }, function(err, entries) {
        if (err) {
        reject(err);
        } else {
        resolve(entries);
        console.log('getWeeklyEntries returns: ', entries);
        }
        })
        })
        }

*/
        addNewEntry(week, achievement, duration, Goals, completed) {
            let trainingGoal = {
                name: week,
                achievement: achievement,
                duration: duration,
                Goals: [{
                    goalID,
                     goalDescription
                 }],
                completed: completed
            }
            console.log('Entry added to page', trainingReminder);
    
            this.db.insert(trainingReminder, function(err, doc) {
                if (err) {
                    console.log('Error adding', doc);
                } else {
                    console.log('added to database');
                }
            })
        }


            
                getPostsByWeek(week){
                    return new Promise ((resolve, reject) => {
                        this.db.find({ 'week': week}, function(err, entries) {
                            if(err) {
                                reject(err);
                            }else {
                                resolve(entries);
                                console.log('function returns: ', entries);
                            }
                        })
                    })
                }
                
            
                        
                    


                getRemoveGoal() {
                    console.log('Running remove goal');
                    this.db.remove({'achievement': '15km travel'}, {}, function(err, docsR){

                    if (err) {
                
                        console.log('error deleting goal');
                
                    } else {
                
                        console.log(docsR, 'documents removed');
                
                    }
                
                })
            }

                deleteEntry(id){
        
                    this.db.remove({_id: id}, {}, function(err, rem) {
                        if(err) {
                            console.log('error in deleteEntry', err);
                        } else {
                            console.log(rem, 'entries deleted');
                        }
                    })
                }
                /*             
               getUpdateGoal() {
                console.log('Running updating goal');
               this.db.update({week: 15, achievement: '15km travel'}, 
               { $set: { 'achievement': '25km travel' } }, {}, function(err, NumUP) {   
                 
                    if (err){
                        console.log('error updating goals', err);
                    } else {
                        console.log('goals updated', NumUP);
                    }
                })
            })
            */
            updateEntry(id, week, achievement, duration, Goals, completed) {

                this.db.update({_id: id}, { week: week,
                    achievement: achievement,
                    duration: duration,
                    Goals: [{
                        goalID,
                         goalDescription
                     }],
                    completed: completed}, {}, function (err, reminderUpdate) {
        
                    if(err) {
                        console.log('error updating goal', reminderUpdate);
                    } else {
                        console.log('goal updated in database');
                    }
                })
            }
        }
    

module.exports = reminder; 

