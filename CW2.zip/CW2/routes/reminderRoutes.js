const express = require('express');
const controller = require('../controllers/reminderControllers');
const auth = require('../auth/auth');
const router = express.Router();
const ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;

router.get("/", controller.landing_page);
router.get("/reminderGoals", controller.reminder_list);
router.get("/insertForm", ensureLoggedIn('/login'), controller.show_new_reminder_goal);
router.post('/insertForm', ensureLoggedIn('/login'), controller.post_reminder_goal);
router.get("/completed", controller.find_completed_entries);
router.get("/incomplete", controller.find_incomplete_entries);
router.get('/reminder/:week', controller.show_week_entries);
router.get('/error', controller.testError500, controller.error500);
router.get('/delete/:id', controller.delete_entry);
router.get('/update/:id', controller.show_update_entry);
router.post('/update/:id', controller.post_update_entry);
router.get('/login', controller.show_login_page);
router.post('/login', auth.authorize('/login'), controller.post_login);
router.get('/register', controller.show_register_page);
router.post('/register', controller.post_new_user);
router.get('/logout', controller.logout);
router.use(controller.error404);
router.use(controller.error500);
router.get('/about', function(req, res) {
    res.redirect('/about.html');
   })
   router.use(function(req, res) {
    res.status(404);
    res.type('text/plain');
    res.send('404 Not found.');
   })
   router.use(function(err, req, res, next) {
    res.status(500);
    res.type('text/plain');
    res.send('Internal Server Error.');
   })
module.exports = router;