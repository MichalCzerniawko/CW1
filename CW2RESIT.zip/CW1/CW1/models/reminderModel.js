const nedb = require('nedb'); 
class reminder {
    constructor(dbFilePath) {
        if (dbFilePath) {
        this.db = new nedb({ filename: dbFilePath, autoload: true });
        console.log('DB connected to ' + dbFilePath);
        } else {
        this.db = new nedb();
        }
} 
        
        init() {
            this.db.insert({
            week: 15,
            achievement: '15km travel',
            Goals: [{
               goalID: 1,
                goalDescription: 'Successfully'
            },
            {
                goalID: 2,
                goalDescription:'Failed'  
            },
            {
                goalID: 2,
                goalDescription:'in way'
            }
 ]
            });
                    console.log(' entry inserted');         
}

getAllEntries() {
    return new Promise((resolve, reject) => {
    this.db.find({}, function(err, entries) {
    if (err) {
    reject(err);
    } else {
    resolve(entries);
    console.log('Entries returns: ', entries); }})})
    } 


    getWeeklyEntries() {
        return new Promise((resolve, reject) => {
        this.db.find({ week:'' }, function(err, entries) {
        if (err) {
        reject(err);
        } else {
        resolve(entries);
        console.log('getWeeklyEntries returns: ', entries);
        }
        })
        })
        }


        addEntry(week, achievement, Goals) {
            var entry = {
            week: week,
            achievement: achievement,
            Goals: Goals,
            published: new Date().toISOString().split('T')[0]
            }
            console.log('entry created', entry);
            this.db.insert(entry, function(err, doc) {
            if (err) {
            console.log('Error inserting entry', subject);
            } else {
            console.log('entry inserted into the database', doc);
            }
            })
            }


            getEntriesByGoal(Goals) {
                return new Promise((resolve, reject) => {
                this.db.find({ 'goal': goals }, function(err, entries) {
                if (err) {
                reject(err);
                } else {
                resolve(entries);
                console.log(' returns: ', entries);
                }
                })
                })
                }


                getRemoveGoal() {
                    console.log('Running remove goal');
                    this.db.remove({'achievement': '15km travel'}, {}, function(err, docsR){

                    if (err) {
                
                        console.log('error deleting goal');
                
                    } else {
                
                        console.log(docsR, 'documents removed');
                
                    }
                
                })}
                             
               getUpdateGoal() {
               this.db.update({week: 15, achievement: '15km travel'}, 
               { $set: { 'goals.goalID': 5 } }, {}, function(err, NumUP) {   
                 
                    if (err){
                        console.log('error updating goals', err);
                    } else {
                        console.log('goals updated', NumUP);
                    }
                })
                
}
}
module.exports = reminder; 

